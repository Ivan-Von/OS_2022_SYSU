#ifndef PRINT_H
#define PRINT_H

void print_something();

#endif