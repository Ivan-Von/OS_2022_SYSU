#include "print.h"

int main() {
    print_something();
}