#include <stdio.h>
#include "print.h"

void print_something() {
    printf("SYSU 2021 Spring Operating System Course.\n");
}