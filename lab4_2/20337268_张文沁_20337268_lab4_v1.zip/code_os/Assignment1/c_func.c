#include <stdio.h>

void function_from_C() {
    printf("This is a function from C.\n");
}